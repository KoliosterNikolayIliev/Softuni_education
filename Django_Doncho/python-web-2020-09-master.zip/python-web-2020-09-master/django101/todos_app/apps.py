from django.apps import AppConfig


class TodosAppConfig(AppConfig):
    name = 'todos_app'
