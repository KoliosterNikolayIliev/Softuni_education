from django.test import TestCase


# Create your tests here.

class Test1(TestCase):
    def test_1(self):
        self.assertTrue(True)
