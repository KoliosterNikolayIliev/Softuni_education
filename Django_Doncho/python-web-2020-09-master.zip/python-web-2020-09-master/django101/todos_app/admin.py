from django.contrib import admin

from todos_app.models import Todo

admin.site.register(Todo)
