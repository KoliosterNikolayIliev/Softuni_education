from django.apps import AppConfig


class Django102Config(AppConfig):
    name = 'django102'
