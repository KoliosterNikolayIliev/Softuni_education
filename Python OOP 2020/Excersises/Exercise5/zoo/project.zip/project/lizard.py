from project.reptile import Reptile


class Lizard(Reptile):
    pass

#
# lizard = Lizard("Tasho")
# print(f'lizard {lizard.name}')
