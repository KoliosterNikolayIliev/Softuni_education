from project.parking_mall.parking_mall import ParkingMall


class Level2(ParkingMall):

    def __init__(self):
        ParkingMall.__init__(self, 100)
