import {html,render} from '../node_modules/lit-html/lit-html.js'
import page from '../node_modules/page/page.mjs'
// import {render,html} from 'https://unpkg.com/lit-html?module';
// import page from "//unpkg.com/page/page.mjs";

export {html,render}
export default page
