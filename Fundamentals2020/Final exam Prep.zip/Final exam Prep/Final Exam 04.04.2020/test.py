x=1
if x is not None:
    print(x)